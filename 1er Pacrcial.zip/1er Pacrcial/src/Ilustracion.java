
public class Ilustracion extends Publicacion{
    
    private String Ilustrador;
    private double alto;
    private double ancho;

    public Ilustracion(String titulo, String añoPublicacion, String Ilustrador, double alto, double ancho) {
        super(titulo, añoPublicacion);
        this.Ilustrador = Ilustrador;
        this.alto = alto;
        this.ancho = ancho;
    }


    
    @Override
    public String toString() {
        return "Ilustracion{" + "Ilustrador=" + Ilustrador + ", alto=" + alto + ", ancho=" + ancho + '}';
    }
    
    
}
