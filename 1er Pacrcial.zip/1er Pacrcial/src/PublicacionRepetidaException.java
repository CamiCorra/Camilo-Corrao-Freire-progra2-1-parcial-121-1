
public class PublicacionRepetidaException extends RuntimeException{
    
    private final static String MESSAGE = "Publicacion repetida";

    public PublicacionRepetidaException() {
        super(MESSAGE);
    }
    
    
    

    
    
    
}
