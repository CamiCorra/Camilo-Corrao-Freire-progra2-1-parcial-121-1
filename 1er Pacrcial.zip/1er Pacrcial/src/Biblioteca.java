import java.util.List;
import java.util.ArrayList;

public class Biblioteca {
    
    private List<Publicacion> listaPublicaciones;

    public Biblioteca() {
        listaPublicaciones = new ArrayList<Publicacion>();
    }
    
    
    public void agregarPublicacion(Publicacion publicacion){
        if (publicacion == null) {
            throw new NullPointerException("La publicacion es null");
        }
        if (listaPublicaciones.contains(publicacion)) {
            throw new PublicacionRepetidaException();
        }
        listaPublicaciones.add(publicacion);
    }
    
    public void mostrarPublicaciones(){
        for (Publicacion publicacion : listaPublicaciones) {
            System.out.println(publicacion);
        }
    }
    
    /* NO ME SALIO
    public void leerPublicaciones(){
        for (Publicacion publicacion : listaPublicaciones) {
            publicacion.leer(publicacion);
        }
            
             
    }
    */     
}

