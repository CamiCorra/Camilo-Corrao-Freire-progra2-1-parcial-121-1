
public class Revista extends Publicacion{
    
    private int nEdicion;

    public Revista(String titulo, String añoPublicacion, int nEdicion) {
        super(titulo, añoPublicacion);
        this.nEdicion = nEdicion;
    }


    @Override
    public String toString() {
        return "Revista{" + "nEdicion=" + nEdicion + '}';
    }
    
    
    
    public void leer() {
        System.out.println("Leyendo revista " + titulo + "...");
    }
    
}
