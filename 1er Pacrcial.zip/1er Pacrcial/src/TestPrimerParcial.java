
public class TestPrimerParcial {

    
    public static void main(String[] args) {
       
        Biblioteca biblio = new Biblioteca();
        
        Publicacion p1 = new Libro("El señor de las moscas", "1960", "Carlitos", Genero.FICCION);
        Publicacion p2 = new Revista("Superman", "2024", 455);
        Publicacion p3 = new Ilustracion("El grito", "1950", "Hugo", 120, 180);
        Publicacion p4 = new Revista("Superman", "2024", 455);
        Publicacion p5 = null;
        Publicacion p6 = p2;
        
        
        try{
            biblio.agregarPublicacion(p1);
            biblio.agregarPublicacion(p2);
            biblio.agregarPublicacion(p3);
            //biblio.agregarPublicacion(p4); //tira excepcion por ser igual a p2 (descomentar para probar)
            //biblio.agregarPublicacion(p5); //tira excepcion por dser null (descomentar para probar)
            //biblio.agregarPublicacion(p6); //tira excepcion por ser igual a p2 (descomentar para probar)
        }
        catch(NullPointerException ex) {
            System.out.println("La publicacion es null");
        }
        catch(PublicacionRepetidaException ex) {
            System.out.println(ex.getMessage());      
        }
        
        biblio.mostrarPublicaciones();
        ///biblio.leerPublicaciones(); no me salio
        
    }

        
        
    
}
