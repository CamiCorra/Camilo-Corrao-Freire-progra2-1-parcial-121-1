
public abstract class Publicacion {
    
    protected String titulo;
    protected String añoPublicacion;

    public Publicacion(String titulo, String añoPublicacion) {
        this.titulo = titulo;
        this.añoPublicacion = añoPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAñoPublicacion() {
        return añoPublicacion;
    }

    
    @Override
    public boolean equals(Object obj){
        if (this == (obj)){
            return true;
        }
        if (obj == null || obj.getClass() != this.getClass()){
            return false;
        }
        Publicacion other = (Publicacion)obj;
        return this.titulo.equals(other.getTitulo()) && this.añoPublicacion.equals(other.getAñoPublicacion());
    }
    
   /* NO ME SALIO
    private boolean sePuedeLeer(Publicacion publi){
        Publicacion other = new Ilustracion("El grito", "1950", "Hugo", 120, 180);
        if (publi.getClass() == other.getClass() ){
            return false;
            }    
        else{
            return true;           
        }
    }
   
    public void leer(Publicacion publi){
        if (sePuedeLeer(publi) == false){
            System.out.println("no se puede leer, es una ilustracion");
        }
        else{
            publi.leer(publi);
        }
    }
    */
    

}
